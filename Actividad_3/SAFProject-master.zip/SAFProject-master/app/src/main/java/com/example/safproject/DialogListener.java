package com.example.safproject;

public interface DialogListener {
    void deleteFile();
}
